<?php

/**
 * Search Form
 *
 *
 * @package distantland
 */
?>

<form class="navbar-form navbar-right" action="<?php echo esc_url(home_url('/')); ?>">
    <div class="form-group myFormGroup">
        <div class="searchbar">
            <input class="search_input" name="s" id="s" type="text" name="" placeholder="Search...">
            <a class="search_icon"><i class="fa fa-search"></i></a>
        </div>
    </div>
</form>