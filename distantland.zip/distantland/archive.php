<?php

/**
 * The template for displaying archive pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package distantland
 */

get_header();
?>
<!-- Blog Area Start -->
<section>
	<div class="container-fluid">
		<div class="row">

			<div class="col-xs-12 noPadding blog-header-area" style="background: #ddd;">
				<div class="blog-section-title text-center">
					<div class="container">
						<?php
						the_archive_title('<h3>', '</h3>');
						the_archive_description('<h2 style="color:#ffff">', '</h2>');
						?>
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<div class="container blog-section">
					<div class="row">
						<div class="col-md-9 col-xs-12">
							<?php if (have_posts()) : ?>
								<?php while (have_posts()) : the_post(); ?>
									<?php get_template_part('template-parts/content/content', get_post_type());
									?>
								<?php endwhile;
								the_posts_navigation(); ?>
							<?php else : ?>
								<?php get_template_part('template-parts/content/content', 'none'); ?>
							<?php endif; ?>
						</div>
						<div class="col-md-3 xs-hidden blog-sidebar">
							<?php get_sidebar(); ?>

						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>
<!-- Blog Area End -->
<?php get_footer(); ?>