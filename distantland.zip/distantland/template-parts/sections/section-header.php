<?php

/**
 * The template part for header
 *
 *
 * @package distantland
 */
?>


<?php if (get_header_image()) : ?>
	<a href="<?php echo esc_url(home_url('/')); ?>" id="custom-header" rel="home">
		<img src="<?php esc_url(header_image()); ?>" width="<?php echo esc_attr(get_custom_header()->width); ?>" height="<?php echo esc_attr(get_custom_header()->height); ?>" alt="<?php echo esc_attr(get_bloginfo('title')); ?>">
	</a>
<?php endif;  ?>

<header class="top">
	<div class="fixedArea container-fluid">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12 noPadding">
				<div class="content-wrapper one">
					<!-- Main Menu Start -->
					<!-- Navbar-->
					<header class="header">
						<nav class="navbar navbar-inverse myNavBar <?php if (is_page() && !is_front_page()) echo 'always-active'; ?>">
							<div class="container">
								<div class="navbar-header myNavbarHeader">
									<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
									<?php
									if (has_custom_logo()) {
										the_custom_logo();
									} else {
									?>
										<a href="<?php echo esc_url(home_url('/')); ?>">
											<h4 class="site-title">
												<?php
												echo esc_html(bloginfo('name'));
												?>
											</h4>
										</a>
									<?php
									}
									?>
									<?php
									$distantland_site_desc = get_bloginfo('description');
									if ($distantland_site_desc) : ?>
										<p <?php if (!empty(get_header_textcolor())) {
												echo "style='color:#" . get_header_textcolor() . "'";
											} ?> class="site-description"><?php echo esc_html($distantland_site_desc); ?></p>
									<?php endif; ?>
								</div>

								<div class="collapse navbar-collapse" id="myNavbar">
									<?php
									wp_nav_menu(
										array(
											'theme_location' => 'primary_menu',
											'container'  => 'ul',
											'menu_class' => 'nav navbar-nav navbar-right navBar',
											'fallback_cb' => 'WP_Bootstrap_Navwalker::fallback',
											'walker' => new WP_Bootstrap_Navwalker()
										)
									);
									?>
									<?php get_search_form(); ?>
								</div>
							</div>
						</nav>
					</header>
					<!-- Main Menu End -->
				</div>
			</div>
		</div>
	</div>
</header>
<!-- Header Area End -->