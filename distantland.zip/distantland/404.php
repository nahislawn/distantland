<?php

/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package distantland
 */
get_header();
?>
<?php
$blog_title = get_theme_mod('blog_title', 'Cemre Bakery Blog');
?>

<!-- Blog Area Start -->
<section class="not-found-area">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xs-12 noPadding blog-header-area" style="background: #ddd;">
				<div class="blog-section-title text-center">
					<div class="container">
						<h3><?php echo esc_html($blog_title); ?></h3>
						<h2><?php esc_html_e('4', 'distantland'); ?><i class="fa fa-smile-o"></i><?php esc_html_e('4', 'distantland'); ?></h2>
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<div class="container not-found-section">
					<div class="row">
						<div class="col-md-12 col-xs-12 text-center">
							<h2><?php esc_html_e('O', 'distantland'); ?><span class="text-primary"><?php esc_html_e('pp', 'distantland'); ?></span><?php esc_html_e('s', 'distantland'); ?></h2>
							<p><?php esc_html_e('The page you were looking for could not be found.', 'distantland'); ?></p>
							<a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary btn-like-icon primary-icon"><?php esc_html_e('Go to Home', 'distantland'); ?> <span class="bticn"><i class="fa fa-home"></i></span></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<?php get_footer(); ?>