<?php

/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package distantland
 */

get_header();
?>

<?php
$blog_title               = get_theme_mod('blog_title', 'Cemre Bakery Blog');
$blog_subtitle            = get_theme_mod('blog_subtitle', 'Our Latest News');
$banner_image = get_theme_mod('distantland_main_blog_banner', get_template_directory_uri() . '/assets/img/slider/slide.png');
?>

<!-- Blog Area Start -->
<section>
	<div class="container-fluid">
		<div class="row">

			<div class="col-xs-12 noPadding blog-header-area" style="background-image: url(<?php echo esc_url($banner_image); ?>)">
				<div class="blog-section-title text-center">
					<div class="container">
						<h3><?php echo esc_html($blog_title); ?></h3>
						<h2 style="color:#ffff"><?php echo esc_html($blog_subtitle); ?></h2>
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<div class="container blog-section">
					<div class="row">
						<div class="col-md-9 col-xs-12">
							<?php
							$distantland_paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
							$args = array('post_type' => 'post', 'paged' => $distantland_paged);
							?>
							<?php if (have_posts()) : ?>
								<?php while (have_posts()) : the_post(); ?>
									<?php get_template_part('template-parts/content/content', get_post_type());
									?>
								<?php endwhile;
								the_posts_navigation();
								?>
							<?php else : ?>
								<?php get_template_part('template-parts/content/content', 'none'); ?>
							<?php endif; ?>
						</div>
						<div class="col-md-3 xs-hidden blog-sidebar">
							<?php get_sidebar(); ?>

						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>
<!-- Blog Area End -->
<?php get_footer(); ?>