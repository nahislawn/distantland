<?php

/**
 * The template for displaying search results pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package distantland
 */

get_header();
?>

<!-- Blog Area Start -->
<section>
	<div class="container-fluid">
		<div class="row">

			<div class="col-xs-12 noPadding blog-header-area" style="background: #ddd;">
				<div class="blog-section-title text-center">
					<div class="container">
						<h3 style="color:#ffff"><?php printf(esc_html__('Search Results for: %s', 'distantland'), '<span>' . get_search_query() . '</span>');
												?></h3>
					</div>
				</div>
			</div>
			<div class="col-xs-12">
				<div class="container blog-section">
					<div class="row">
						<div class="col-md-9 col-xs-12">
							<?php if (have_posts()) : ?>
								<?php while (have_posts()) : the_post(); ?>
									<?php get_template_part('template-parts/content/content', 'search'); ?>
								<?php endwhile; ?>
								<!-- Pagination -->
								<?php
								// Previous/next page navigation.
								the_posts_navigation();
								?>
								<!-- Pagination -->
							<?php else : ?>
								<?php get_template_part('template-parts/content/content', 'none'); ?>
							<?php endif; ?>

						</div>
						<div class="col-md-3 xs-hidden blog-sidebar">
							<?php get_sidebar(); ?>

						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</section>
<!-- Blog Area End -->
<?php get_footer(); ?>