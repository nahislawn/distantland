<?php
$above_footer_title               = get_theme_mod('above_footer_btm_main_ttl', 'Cemre Bakery Location');
$above_footer_subtitle            = get_theme_mod('above_footer_btm_main_sub_ttl', 'Cemre Bakery Address');
$above_footer_text           = get_theme_mod('footer_above_btm_main_text', 'I must explain to you how all this mistaken idea of denouncing pleure and praising pain was born.');
$above_footer_title_2              = get_theme_mod('above_footer_btm_sidebar_ttl', 'NEW CAKE!!! GET IT FOR $12/PAX (LIMITED)');
$above_footer_subtitle_2           = get_theme_mod('above_footer_btm_sidebar_sub_ttl', 'Strawberry Pancake');
$above_footer_text_2            = get_theme_mod('footer_above_btm_sidebar_text', 'Show More');
$above_footer_link           = get_theme_mod('footer_above_btm_sidebar_link', '#');
$background_image        = get_theme_mod('distantland_bg_img_footer_above_main', get_template_directory_uri() . '/assets/img/address/contactbg.png');
$banner_image        = get_theme_mod('distantland_bg_banner_img_footer_above', get_template_directory_uri() . '/assets/img/new/shop2.png');
$social_icons = get_theme_mod('footer_above', distantland_get_address_icon_default());
?>

<!-- Address Section Start -->
<section id="section7" class="row address parallax-window" data-parallax="scroll" data-image-src="<?php echo esc_url($background_image); ?>">
	<div class="col-md-12">
		<div class="row flex-container">
			<div class="col-md-5 col-md-offset-1 addess-description">
				<?php if (!empty($above_footer_title)) : ?>
					<span><?php echo esc_html($above_footer_title); ?></span>
				<?php endif; ?>
				<?php if (!empty($above_footer_subtitle)) : ?>
					<h2><?php echo esc_html($above_footer_subtitle); ?></h2>
				<?php endif; ?>
				<?php if (!empty($above_footer_text)) : ?>
					<p><?php echo esc_html($above_footer_text); ?></p>
				<?php endif; ?>
				<ul>
					<?php
					if (!empty($social_icons)) {
						$social_icons = json_decode($social_icons);
						foreach ($social_icons as $social_icon_item) {
							$text = !empty($social_icon_item->text) ? apply_filters('distantland_translate_single_string', $social_icon_item->text, 'address section') : '';
							$icon = !empty($social_icon_item->icon_value) ? apply_filters('distantland_translate_single_string', $social_icon_item->icon_value, 'address section') : '';
					?>
							<li class="address-section">
								<div class="row">
									<div class="col-md-2 col-sm-2 col-xs-2">
										<?php if (!empty($icon)) : ?>
											<i class="fa <?php echo esc_html($icon); ?>"></i>
										<?php endif; ?>

									</div>
									<div class="col-md-10 col-sm-10 col-xs-10 lineHeight">
										<?php if (!empty($text)) : ?>
											<?php echo wp_kses_post($text); ?>
										<?php endif; ?>
									</div>
								</div>
							</li>
					<?php }
					} ?>
				</ul>
			</div>
			<div class="col-md-6 banner-area" style="background-image: url(<?php echo esc_url($banner_image); ?>)">
				<div class="adress-area-banner">
					<div class="content text-center">
						<?php if (!empty($above_footer_title_2)) : ?>
							<span><?php echo esc_html($above_footer_title_2); ?></span>
						<?php endif; ?>
						<?php if (!empty($above_footer_subtitle_2)) : ?>
							<h2><?php echo esc_html($above_footer_subtitle_2); ?></h2>
						<?php endif; ?>
						<?php if (!empty($above_footer_text_2)) : ?>
							<h3><a href="<?php echo esc_url($above_footer_link); ?>"><?php echo esc_html($above_footer_text_2); ?></a>
							</h3>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!-- Adress Section End -->
<?php

$footer_logo			= get_theme_mod('footer_bg_logo_img', esc_url(get_template_directory_uri() . '/assets/img/logo/cemrebakerytextlogo.png'));
$footer_title			= get_theme_mod('footer_btm_ttl', 'Fresh Bakery Store');
$footer_text			= get_theme_mod('footer_btm_text', 'I must explain to you how all this mistaken idea of denoun pleure and praising pain was born and give you a coete account of the system.');
$social_icons = get_theme_mod('social_icons', distantland_get_social_icon_default());


?>


<!-- Footer Start -->
<footer class="footer-area">
	<div class="container main-footer">
		<div class="row">
			<div class="col-md-3 col-sm-6 col-xs-12">
				<div class="footer-logo pb-25">
					<div class="col-md-12 noPadding logo-text">
						<?php if (!empty($footer_logo)) : ?>
							<a class="" href=""><img class="img-responsive" src="<?php echo esc_url($footer_logo); ?>" alt="restorant" /></a>
						<?php endif; ?>
						<?php if (!empty($footer_title)) : ?>
							<p class="footer-title colorfullText"><?php echo esc_html($footer_title); ?></p>
						<?php endif; ?>
					</div>
				</div>
				<p class="footer-text">
					<?php if (!empty($footer_text)) : ?>
						<?php echo esc_html($footer_text); ?>
					<?php endif; ?>
				</p>
				<div class="footer-social">
					<ul class="list-group">
						<?php
						if (!empty($social_icons)) {
							$social_icons = json_decode($social_icons);
							foreach ($social_icons as $social_icon_item) {
								$link = !empty($social_icon_item->link) ? apply_filters('distantland_translate_single_string', $social_icon_item->link, 'address section') : '';
								$icon = !empty($social_icon_item->icon_value) ? apply_filters('distantland_translate_single_string', $social_icon_item->icon_value, 'address section') : '';
						?>
								<?php if (!empty($icon)) : ?>
									<li>
										<a href="<?php echo esc_url($link); ?>"><i class="fa <?php echo esc_html($icon); ?>"></i></a>
									</li>

								<?php endif; ?>

						<?php }
						} ?>
					</ul>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12">
				<div class="single-widget">
					<?php if (is_active_sidebar('distantland-footer-widget-area')) { ?>

						<?php dynamic_sidebar('distantland-footer-widget-area'); ?>

					<?php } ?>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12">
				<div class="single-widget">
					<?php if (is_active_sidebar('distantland-footer-widget-area-2')) { ?>

						<?php dynamic_sidebar('distantland-footer-widget-area-2'); ?>

					<?php } ?>
				</div>
			</div>
			<div class="col-md-3 col-sm-6 col-xs-12">
				<div class="single-widget">
					<?php if (is_active_sidebar('distantland-footer-widget-area-3')) { ?>

						<?php dynamic_sidebar('distantland-footer-widget-area-3'); ?>

					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-bottom text-center">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<?php
					$footer_copyright	= get_theme_mod('footer_copyright', 'Copyright &copy; [current_year] [site_title] | Powered by [theme_author]');
					if (!empty($footer_copyright)) { ?>
						<?php
						$distantland_copyright_allowed_tags = array(
							'[current_year]' => date('Y'),
							'[site_title]'   => get_bloginfo('name'),
							'[theme_author]' => sprintf(__('<a href="#">Cemreworks</a>', 'distantland')),
						);
						?>
						<div class="copyright-text">
							<?php
							echo apply_filters('distantland_footer_copyright', wp_kses_post(distantland_str_replace_assoc($distantland_copyright_allowed_tags, $footer_copyright)));
							?>
						</div>
					<?php }	?>
				</div>
			</div>
		</div>
	</div>
</footer>
<!-- Footer End -->
</div>
<?php wp_footer(); ?>
</body>

</html>