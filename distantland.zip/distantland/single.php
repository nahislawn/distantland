<?php

/**
 * The template for displaying archive pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package distantland
 */

get_header();
?>
<!-- Blog Area Start -->
<section>
	<div class="container-fluid">
		<div class="row">
			<?php if (have_posts()) : ?>

				<div class="col-xs-12 noPadding blog-header-area" style="background: #ddd;">
					<div class="blog-section-title text-center">
						<div class="container">
							<ol class="breadcrumb breadcrumb-single text-center">
								<?php distantland_breadcrumbs();	?>

							</ol>
							<h3><?php the_category(', '); ?></h3>
							<?php the_title('<h2 style="color:#fff">', '</h2>'); ?>
						</div>
					</div>
				</div>
				<div class="container">
					<div class="col-md-9 col-xs-12 blog-content">
						<?php while (have_posts()) : the_post(); ?>
							<?php get_template_part('template-parts/content/content', get_post_type());
							the_post_navigation(
								array(
									'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'distantland') . '</span> <span class="nav-title">%title</span>',
									'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'distantland') . '</span> <span class="nav-title">%title</span>',
								)
							);
							?>
						<?php endwhile; ?>
						<?php comments_template('', true); // show comments  
						?>
					</div>
					<div class="col-md-3 hidden-xs blog-sidebar">
						<?php get_sidebar(); ?>
					</div>
				</div>
			<?php endif; ?>

		</div>
	</div>
</section>
<!-- Blog Area End -->
<?php get_footer(); ?>