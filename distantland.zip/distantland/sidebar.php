<?php if (!is_active_sidebar('distantland-sidebar-primary')) {
    return;
} ?>
		<?php dynamic_sidebar('distantland-sidebar-primary'); ?>
