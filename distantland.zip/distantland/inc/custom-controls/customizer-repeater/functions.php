<?php

/**
 * Include customizer.php file.
 *
 * @package customizer-controls
 */

define('CUSTOMIZER_REPEATER_VERSION', '1.1.0');
require get_template_directory() . '/inc/custom-controls/customizer-repeater/inc/customizer.php';
