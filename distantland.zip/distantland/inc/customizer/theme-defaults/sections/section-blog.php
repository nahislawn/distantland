<?php
if (!function_exists('distantland_blog')) :
    function distantland_blog()
    {
        $distantland_hs_blog              = get_theme_mod('hs_distantland_blog', '1');
        $distantland_blog_title         = get_theme_mod('distantland_blog_title', 'CEMRE BAKERY Blog');
        $distantland_blog_subtitle     = get_theme_mod('distantland_blog_subtitle', 'Our Latest News');
        $distantland_blog_display_num     = get_theme_mod('distantland_blog_display_num', '2');
        if ($distantland_hs_blog == '1') {
?>
            <!-- distantland_blog Area Start -->
            <section id="section5" class="blog-area">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="blog-section-title text-center">
                            <?php if (!empty($distantland_blog_title)) : ?>
                                <h3><?php echo esc_html($distantland_blog_title); ?></h3>
                            <?php endif; ?>
                            <?php if (!empty($distantland_blog_subtitle)) : ?>
                                <h2><?php echo wp_kses_post($distantland_blog_subtitle); ?></h2>
                            <?php endif; ?>

                        </div>
                    </div>
                    <div class="row">
                        <div class="container blog-section">

                            <?php
                            $distantland_blogs_args = array('post_type' => 'post', 'posts_per_page' => $distantland_blog_display_num, 'post__not_in' => get_option("sticky_posts"));
                            $distantland_blog_wp_query = new WP_Query($distantland_blogs_args);
                            if ($distantland_blog_wp_query) {
                                while ($distantland_blog_wp_query->have_posts()) : $distantland_blog_wp_query->the_post(); ?>
                                    <div class="col-md-6">
                                        <div class="row">
                                            <div class="
                    blog-main-section-date
                    col-md-4 col-sm-4 col-xs-12
                    noPadding
                  ">
                                                <?php distantland_post_thumbnail(); ?>
                                            </div>

                                            <div class="
              blog-main-section-date blog-section-description
                    col-md-8 col-sm-8 col-xs-12
                    
                  ">
                                                <?php
                                                the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');

                                                the_excerpt();
                                                distantland_posted_on();
                                                distantland_posted_by();
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                endwhile;
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </section>
            <!-- distantland_blog Area End -->
<?php
        }
    }
endif;
if (function_exists('distantland_blog')) {
    $section_priority = apply_filters('distantland_section_priority', 15, 'distantland_blog');
    add_action('distantland_sections', 'distantland_blog', absint($section_priority));
}
