<?php
if (!function_exists('distantland_service')) :
    function distantland_service()
    {
        $hs_service                    = get_theme_mod('hide_show_services', '1');
        $service_title                = get_theme_mod('services_btm_ttl', 'SERVE YOU SINCE 1988');
        $service_subtitle            = get_theme_mod('services_btm_sub_ttl', 'Welcome To Cemre Bakery');
        $service_description        = get_theme_mod('services_btm_textarea', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis leo vitae lacinia congue.');
        $service_contents            = get_theme_mod('services', distantland_get_service_default());
        if ($hs_service == '1') {
?>

            <!-- Section2 Start -->
            <section id="section2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="maintext text-center">

                                <?php if (!empty($service_title)) : ?>
                                    <span class="service-title"><?php echo wp_kses_post($service_title); ?></span>
                                <?php endif; ?>

                                <?php if (!empty($service_subtitle)) : ?>
                                    <h2><?php echo wp_kses_post($service_subtitle); ?></h2>
                                <?php endif; ?>

                                <?php if (!empty($service_description)) : ?>
                                    <p><?php echo wp_kses_post($service_description); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row shapes">

                        <?php
                        if (!empty($service_contents)) {
                            $service_contents = json_decode($service_contents);
                            foreach ($service_contents as $service_item) {
                                $distantland_service_title = !empty($service_item->title) ? apply_filters('distantland_translate_single_string', $service_item->title, 'service section') : '';
                                $text = !empty($service_item->text) ? apply_filters('distantland_translate_single_string', $service_item->text, 'service section') : '';
                                $icon = !empty($service_item->icon_value) ? apply_filters('distantland_translate_single_string', $service_item->icon_value, 'service section') : '';
                        ?>
                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="row">
                                        <div class="col-md-12 minHeightProp">
                                            <div class="shapes-section2">
                                                <i class="fa <?php echo esc_html($icon); ?>" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="text-center">
                                                <?php if (!empty($distantland_service_title)) : ?>
                                                    <span><?php echo esc_html($distantland_service_title); ?></span>
                                                <?php endif; ?>

                                                <?php if (!empty($text)) : ?>
                                                    <p><?php echo esc_html($text); ?></p>
                                                <?php endif; ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        <?php
                            }
                        } ?>
                    </div>
                </div>
            </section>
            <!-- Section2 End -->
<?php
        }
    }
endif;
if (function_exists('distantland_service')) {
    $section_priority = apply_filters('distantland_section_priority', 13, 'distantland_service');
    add_action('distantland_sections', 'distantland_service', absint($section_priority));
}
