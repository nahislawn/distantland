<?php
if (!function_exists('distantland_above_footer')) :
    function distantland_above_footer()
    {
        $hs_service                    = get_theme_mod('hide_show_above_footer', '1');
        $above_footer_title               = get_theme_mod('above_footer_btm_main_ttl', 'CemreBakery Location');
        $above_footer_subtitle            = get_theme_mod('above_footer_btm_main_sub_ttl', 'CemreBakery Address');
        $above_footer_text           = get_theme_mod('footer_above_btm_main_text', 'I must explain to you how all this mistaken idea of denouncing pleure and praising pain was born.');
        $above_footer_title_2              = get_theme_mod('above_footer_btm_sidebar_ttl', 'NEW CAKE!!! GET IT FOR $12/PAX (LIMITED)');
        $above_footer_subtitle_2           = get_theme_mod('above_footer_btm_sidebar_sub_ttl', 'Strawberry Pancake');
        $above_footer_text_2            = get_theme_mod('footer_above_btm_sidebar_text', 'Show More');
        $above_footer_link           = get_theme_mod('footer_above_btm_sidebar_link', '#');
        $background_image        = get_theme_mod('distantland_bg_img_footer_above_main', get_template_directory_uri() . '/assets/img/address/contactbg.png');
        $banner_image        = get_theme_mod('distantland_bg_banner_img_footer_above', get_template_directory_uri() . '/assets/img/new/shop.png');
        $social_icons = get_theme_mod('footer_above', distantland_get_address_icon_default());
        if ($hs_service == '1') {
?>

            <!-- Address Section Start -->
            <section id="section7" class="row address parallax-window" data-parallax="scroll" data-image-src="<?php echo esc_url($background_image); ?>">
                <div class="col-md-12">
                    <div class="row flex-container">
                        <div class="col-md-5 col-md-offset-1 addess-description">
                            <?php if (!empty($above_footer_title)) : ?>
                                <span><?php echo esc_html($above_footer_title); ?></span>
                            <?php endif; ?>
                            <?php if (!empty($above_footer_subtitle)) : ?>
                                <h2><?php echo esc_html($above_footer_subtitle); ?></h2>
                            <?php endif; ?>
                            <?php if (!empty($above_footer_text)) : ?>
                                <p><?php echo esc_html($above_footer_text); ?></p>
                            <?php endif; ?>
                            <ul>
                                <?php
                                if (!empty($social_icons)) {
                                    $social_icons = json_decode($social_icons);
                                    foreach ($social_icons as $social_icon_item) {
                                        $text = !empty($social_icon_item->text) ? apply_filters('distantland_translate_single_string', $social_icon_item->text, 'address section') : '';
                                        $icon = !empty($social_icon_item->icon_value) ? apply_filters('distantland_translate_single_string', $social_icon_item->icon_value, 'address section') : '';
                                ?>
                                        <li class="address-section">
                                            <div class="row">
                                                <div class="col-md-2 col-sm-2 col-xs-2">
                                                    <?php if (!empty($icon)) : ?>
                                                        <i class="fa <?php echo esc_html($icon); ?>"></i>
                                                    <?php endif; ?>

                                                </div>
                                                <div class="col-md-10 col-sm-10 col-xs-10 lineHeight">
                                                    <?php if (!empty($text)) : ?>
                                                        <?php echo wp_kses_post($text); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                <?php }
                                } ?>
                            </ul>
                        </div>
                        <div class="col-md-6 banner-area" style="background-image: url(<?php echo esc_url($banner_image); ?>)">
                            <div class="adress-area-banner">
                                <div class="content text-center">
                                    <?php if (!empty($above_footer_title_2)) : ?>
                                        <span><?php echo esc_html($above_footer_title_2); ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($above_footer_subtitle_2)) : ?>
                                        <h2><?php echo esc_html($above_footer_subtitle_2); ?></h2>
                                    <?php endif; ?>
                                    <?php if (!empty($above_footer_text_2)) : ?>
                                        <h3><a href="<?php echo esc_url($above_footer_link); ?>"><?php echo esc_html($above_footer_text_2); ?></a>
                                        </h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Adress Section End -->
<?php
        }
    }
endif;
if (function_exists('distantland_above_footer')) {
    $section_priority = apply_filters('distantland_section_priority', 16, 'distantland_above_footer');
    add_action('distantland_sections', 'distantland_above_footer', absint($section_priority));
}
