<?php
if (!function_exists('distantland_chefs')) :
    function distantland_chefs()
    {
        $distantland_hs_chefs              = get_theme_mod('hide_show_chefs', '1');
        $distantland_chefs_title         = get_theme_mod('chefs_btm_ttl', 'Our Chefs');
        $distantland_chefs_subtitle     = get_theme_mod('chefs_btm_sub_ttl', 'Our latest chefs');
        $chefs_contents            = get_theme_mod('chefs', distantland_get_chefs_default());
        if ($distantland_hs_chefs == '1') {
?>
            <!-- Chefs Area Start -->
            <section id="section6" class="chefs-area">
                <div class="container">
                    <div class="chefs-section-title text-center">
                        <?php if (!empty($distantland_chefs_title)) : ?>
                            <h3><?php echo esc_html($distantland_chefs_title); ?></h3>
                        <?php endif; ?>
                        <?php if (!empty($distantland_chefs_subtitle)) : ?>
                            <h2><?php echo wp_kses_post($distantland_chefs_subtitle); ?></h2>
                        <?php endif; ?>
                    </div>

                    <div class="row chefs-section">
                        <?php
                        if (!empty($chefs_contents)) {
                            $chefs_contents = json_decode($chefs_contents);
                            foreach ($chefs_contents as $chef_item) {
                                $distantland_chef_title = !empty($chef_item->title) ? apply_filters('distantland_translate_single_string', $chef_item->title, 'chefs section') : '';
                                $image = !empty($chef_item->image_url) ? apply_filters('distantland_translate_single_string', $chef_item->image_url, 'chefs section') : '';
                        ?>
                                <div class="col-md-3 chefs-img">
                                    <?php if (!empty($distantland_chef_title)) : ?>
                                        <h4><?php echo esc_html($distantland_chef_title); ?></h4>
                                    <?php endif; ?>
                                    <img src="<?php echo esc_url($image); ?>" alt="Rounded Image" class="img-rounded img-responsive" />
                                </div>
                        <?php }
                        }; ?>
                    </div>
                </div>
            </section>
            <!-- Chefs Area End -->
<?php
        }
    }
endif;
if (function_exists('distantland_chefs')) {
    $section_priority = apply_filters('distantland_section_priority', 16, 'distantland_chefs');
    add_action('distantland_sections', 'distantland_chefs', absint($section_priority));
}
