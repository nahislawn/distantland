<?php
if (!function_exists('distantland_info')) :
    function distantland_info()
    {
        $hs_info            = get_theme_mod('hide_show_info', '1');
        $info_contents        = get_theme_mod('info', distantland_get_info_default());
        if ($hs_info == '1') {
?>
            <!-- Section1 Start -->
            <section id="section1" class="topOff">
                <div class="container">
                    <div class="row">
                        <?php
                        if (!empty($info_contents)) {
                            $info_contents = json_decode($info_contents);
                            foreach ($info_contents as $info_item) {
                                $distantland_info_title = !empty($info_item->title) ? apply_filters('distantland_translate_single_string', $info_item->title, 'info section') : '';
                                $distantland_info_subtitle = !empty($info_item->subtitle) ? apply_filters('distantland_translate_single_string', $info_item->subtitle, 'info section') : '';
                                $text = !empty($info_item->text) ? apply_filters('distantland_translate_single_string', $info_item->text, 'info section') : '';
                        ?>

                                <div class="col-md-4 col-sm-4 col-xs-12">
                                    <div class="panel panel-default">
                                        <div class="panel-body colorfullPanel text-center">
                                            <?php if (!empty($distantland_info_title)) : ?>
                                                <h3><?php echo esc_html($distantland_info_title); ?></h3>
                                            <?php endif; ?>

                                            <?php if (!empty($distantland_info_subtitle)) : ?>
                                                <h2><?php echo esc_html($distantland_info_subtitle); ?></h2>
                                            <?php endif; ?>
                                            </h2>

                                            <?php if (!empty($text)) : ?>
                                                <p><?php echo esc_html($text); ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                        <?php }
                        } ?>
                    </div>
                </div>
            </section>
            <!-- Section1 End -->


            </div>
            </div>
            </div>
            </div>
            </section>


<?php
        }
    }
endif;
if (function_exists('distantland_info')) {
    $section_priority = apply_filters('distantland_section_priority', 12, 'distantland_info');
    add_action('distantland_sections', 'distantland_info', absint($section_priority));
}
