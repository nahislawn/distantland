<?php
if (!function_exists('distantland_banner')) :
    function distantland_banner()
    {
        $hs_service                    = get_theme_mod('hide_show_banner', '1');
        $banner_title               = get_theme_mod('banner_btm_ttl', 'NEW CAKE!!! GET IT FOR $12/PAX (LIMITED)');
        $banner_subtitle            = get_theme_mod('banner_btm_sub_ttl', 'Strawberry Pancake');
        $banner_text        = get_theme_mod('banner_btm_text', 'Show More');
        $banner_link        = get_theme_mod('banner_btm_link', '#');
        $banner_image        = get_theme_mod('distantland_bg_img', get_template_directory_uri() . '/assets/img/new/shop.png');
        if ($hs_service == '1') {
?>


            <!-- Banner Start -->
            <section class="banner">

                <div class="container">
                    <div class="banner" style="background-image: url(<?php echo esc_url($banner_image); ?>)">
                        <div class="content text-center">
                            <?php if (!empty($banner_title)) : ?>
                                <span><?php echo esc_html($banner_title); ?></span>
                            <?php endif; ?>

                            <?php if (!empty($banner_subtitle)) : ?>
                                <h2><?php echo esc_html($banner_subtitle); ?></h2>
                            <?php endif; ?>
                            <?php if (!empty($banner_text)) : ?>
                                <h3><a href="<?php if (!empty($banner_link)) echo esc_url($banner_link); ?>"><?php echo esc_html($banner_text); ?></a></h3>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Banner End -->


<?php
        }
    }
endif;
if (function_exists('distantland_banner')) {
    $section_priority = apply_filters('distantland_section_priority', 14, 'distantland_banner');
    add_action('distantland_sections', 'distantland_banner', absint($section_priority));
}
