<?php
if (!function_exists('distantland_carousel')) :
    function distantland_carousel()
    {
        $hs_service                    = get_theme_mod('hide_show_carousel', '1');
        $carousel_title               = get_theme_mod('carousel_btm_ttl', 'PREMIUM QUALITY');
        $carousel_subtitle            = get_theme_mod('carousel_btm_sub_ttl', 'Cemre Bakery Fresh Cakes');
        $carousel = get_theme_mod('carousel', distantland_get_carousel_default());
        if ($hs_service == '1') {
?>




            <!-- Section3 Start -->
            <section id="section3">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="section-title text-center">
                                <?php if (!empty($carousel_title)) : ?>
                                    <h3><?php echo esc_html($carousel_title); ?></h3>
                                <?php endif; ?>
                                <?php if (!empty($carousel_subtitle)) : ?>
                                    <h2><?php echo esc_html($carousel_subtitle); ?></h2>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="container">
                            <div class="col-md-12 noPadding">
                                <div id="news-slider" class="news-slider owl-theme owl-carousel">
                                    <?php
                                    if (!empty($carousel)) {
                                        $carousel = json_decode($carousel);
                                        foreach ($carousel as $carousel_item) {
                                            $distantland_carousel_title = !empty($carousel_item->title) ? apply_filters('distantland_translate_single_string', $carousel_item->title, 'carouselr section') : '';
                                            $text = !empty($carousel_item->text) ? apply_filters('distantland_translate_single_string', $carousel_item->text, 'carouselr section') : '';
                                            $distantland_carousel_link = !empty($carousel_item->link) ? apply_filters('distantland_translate_single_string', $carousel_item->link, 'carouselr section') : '';
                                            $image = !empty($carousel_item->image_url) ? apply_filters('distantland_translate_single_string', $carousel_item->image_url, 'carouselr section') : '';
                                    ?>
                                            <div class="post-slide">
                                                <div class="post-img">
                                                    <div class="post-abs">
                                                        <?php if (!empty($distantland_carousel_title)) : ?>
                                                            <p><?php echo wp_kses_post($distantland_carousel_title); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if (!empty($image)) : ?>
                                                        <img src="<?php echo esc_url($image); ?>" alt="" />
                                                    <?php endif; ?>
                                                </div>

                                                <h3 class="post-title">

                                                    <?php if (!empty($distantland_carousel_link)) : ?>
                                                        <a class="default-btn" href="<?php echo wp_kses_post($distantland_carousel_link); ?>"><?php echo wp_kses_post($distantland_carousel_title); ?></a>
                                                    <?php endif; ?>

                                                </h3>
                                                <?php if (!empty($text)) : ?>
                                                    <p class="post-description"><?php echo wp_kses_post($text); ?></p>
                                                <?php endif; ?>


                                            </div>
                                    <?php }
                                    } ?>
                                </div>
                            </div>
                        </div>
                    </div>
            </section>
            <!-- Section3 End -->

<?php
        }
    }
endif;
if (function_exists('distantland_carousel')) {
    $section_priority = apply_filters('distantland_section_priority', 14, 'distantland_carousel');
    add_action('distantland_sections', 'distantland_carousel', absint($section_priority));
}
