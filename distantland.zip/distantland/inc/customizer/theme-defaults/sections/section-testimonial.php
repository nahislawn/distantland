<?php
if (!function_exists('distantland_testimonial')) :
    function distantland_testimonial()
    {
        $hs_service                    = get_theme_mod('hide_show_testimonial', '1');
        $testimonial_title               = get_theme_mod('testimonial_btm_ttl', 'What We Say');
        $testimonial_subtitle            = get_theme_mod('testimonial_btm_sub_ttl', 'Customer Testimonial');
        $background_image        = get_theme_mod('distantland_bg_img_testimonial', get_template_directory_uri() . '/assets/img/testimonial/testomonialsbg.png');
        $testimonials = get_theme_mod('testimonials', distantland_get_testimonial_default());
        if ($hs_service == '1') {
?>



            <!-- Testimonial Area Start -->
            <section id="section4" class="parallax-window" data-parallax="scroll" data-image-src="<?php echo esc_url($background_image); ?>">
                <?php if (!empty($testimonial_title)) : ?>
                    <h3><?php echo esc_html($testimonial_title); ?></h3>
                <?php endif; ?>
                <?php if (!empty($testimonial_subtitle)) : ?>
                    <h2><?php echo esc_html($testimonial_subtitle); ?></h2>
                <?php endif; ?>
                <div class="testimonial-area owl-theme owl-carousel">
                    <?php
                    if (!empty($testimonials)) {
                        $testimonials = json_decode($testimonials);
                        foreach ($testimonials as $testimonial_item) {
                            $distantland_testimonial_title = !empty($testimonial_item->title) ? apply_filters('distantland_translate_single_string', $testimonial_item->title, 'testimonial section') : '';
                            $subtitle = !empty($testimonial_item->subtitle) ? apply_filters('distantland_translate_single_string', $testimonial_item->subtitle, 'testimonial section') : '';
                            $text = !empty($testimonial_item->text) ? apply_filters('distantland_translate_single_string', $testimonial_item->text, 'testimonial section') : '';
                    ?>

                            <div class="col-md-12 col-sm-12 col-xs-12 noPadding text-center">
                                <div class="single-testimonial">
                                    <div class="testimonial-info">
                                        <div class="testimonial-content">
                                            <?php if (!empty($text)) : ?>
                                                <p class="post-description"><?php echo wp_kses_post($text); ?></p>
                                            <?php endif; ?>
                                            <?php if (!empty($distantland_testimonial_title)) : ?>
                                                <h4><?php echo wp_kses_post($distantland_testimonial_title); ?></h4>
                                            <?php endif; ?>
                                            <?php if (!empty($subtitle)) : ?>
                                                <h5><?php echo wp_kses_post($subtitle); ?></h5>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    <?php }
                    } ?>
                </div>
            </section>
            <!-- Testimonial Area End -->



<?php
        }
    }
endif;
if (function_exists('distantland_testimonial')) {
    $section_priority = apply_filters('distantland_section_priority', 14, 'distantland_testimonial');
    add_action('distantland_sections', 'distantland_testimonial', absint($section_priority));
}
