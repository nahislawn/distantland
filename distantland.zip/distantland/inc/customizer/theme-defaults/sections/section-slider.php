<?php
if (!function_exists('distantland_slider')) :
	function distantland_slider()
	{
		$slider = get_theme_mod('slider', distantland_get_slider_default());
?>

		<!-- Section0 Area Start -->
		<section id="section0" class="slider-area">
			<div class="main-slider owl-theme owl-carousel">
				<!-- Start Single Slide -->
				<?php
				if (!empty($slider)) {
					$slider = json_decode($slider);
					foreach ($slider as $slide_item) {
						$distantland_slide_title = !empty($slide_item->title) ? apply_filters('distantland_translate_single_string', $slide_item->title, 'slider section') : '';
						$subtitle = !empty($slide_item->subtitle) ? apply_filters('distantland_translate_single_string', $slide_item->subtitle, 'slider section') : '';
						$text = !empty($slide_item->text) ? apply_filters('distantland_translate_single_string', $slide_item->text, 'slider section') : '';
						$button = !empty($slide_item->text2) ? apply_filters('distantland_translate_single_string', $slide_item->text2, 'slider section') : '';
						$distantland_slide_link = !empty($slide_item->link) ? apply_filters('distantland_translate_single_string', $slide_item->link, 'slider section') : '';
						$image = !empty($slide_item->image_url) ? apply_filters('distantland_translate_single_string', $slide_item->image_url, 'slider section') : '';
				?>



						<?php if (!empty($image)) : ?>

							<div class="single-slide item" style="background-image: url(<?php echo esc_url($image); ?>)">
								<!-- Start Slider Content -->
								<div class="slider-content-area">
									<div class="row">
										<div class="slide-content-wrapper text-center">
											<div class="slide-content">
												<?php if (!empty($distantland_slide_title)) : ?>
													<h3><?php echo wp_kses_post($distantland_slide_title); ?></h3>
												<?php endif; ?> </h3>

												<?php if (!empty($subtitle)) : ?>
													<h2><?php echo wp_kses_post($subtitle); ?></h2>
												<?php endif; ?>
												<?php if (!empty($text)) : ?>
													<p><?php echo wp_kses_post($text); ?></p>
												<?php endif; ?>

												<?php if (!empty($button)) : ?>
													<a class="default-btn" href="<?php echo esc_url($distantland_slide_link); ?>"><?php echo wp_kses_post($button); ?></a>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
								<!-- Start Slider Content -->
							</div>
				<?php endif;
					}
				} ?>
				<!-- End Single Slide -->
			</div>
		</section>
<?php }
endif; ?>
<!-- Section0 Area End -->
<?php
if (function_exists('distantland_slider')) {
	$section_priority = apply_filters('distantland_section_priority', 11, 'distantland_slider');
	add_action('distantland_sections', 'distantland_slider', absint($section_priority));
}
