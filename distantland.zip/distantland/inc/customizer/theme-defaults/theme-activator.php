<?php

/**
 * Theme Activate Function and register default pages
 */

function themeactivate()
{
    $item_details_page = get_option('item_details_page');
    if (!$item_details_page) {
        require get_template_directory() . '/inc/customizer/theme-defaults/default-pages/home-page.php';
        require get_template_directory() . '/inc/customizer/theme-defaults/default-pages/upload-media.php';
        require get_template_directory() . '/inc/customizer/theme-defaults/default-widgets/default-widget.php';

        update_option('item_details_page', 'Done');
    }
}

themeactivate();
