<?php

$activate = array(
	'distantland-sidebar-primary' => array(
		'search-2',
		'recent-posts-1',
		'archives-2',
	),
	'distantland-footer-widget-area' => array(
		'text-1',
	),

	'distantland-footer-widget-area-2' => array(
		'text-2',
	),

	'distantland-footer-widget-area-3' => array(
		'text-3',
	)
);
/* the default titles will appear */
update_option('widget_text', array(
	1 => array(
		'title' => 'information',
		'text' => '<p class="lock"></p><ul><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2 text-center">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>About Our Shop</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>Top Sellers</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>Our Blog</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>New Products</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>Secure Shopping</p></a>
		  </div>
		</div>
	  </li></ul>'
	),
	2 => array(
		'title' => 'useful links',
		'text' => '<p class="lock"></p><ul><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2 text-center">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>About Our Shop</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>Top Sellers</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>Our Blog</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>New Products</p></a>
		  </div>
		</div>
	  </li><li class="footer-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<div class="footer-icon"></div>
		  </div>
		  <div class="col-md-10 col-sm-10 col-xs-10">
			<a href="#"><p>Secure Shopping</p></a>
		  </div>
		</div>
	  </li></ul>'
	),
	3 => array(
		'title' => 'get in touch',
		'text' => '<p class="lock"></p>
	<p>
	  Your address goes here, Street<br>City, Roadno 785 New York
	</p>
	<p>+880 548 986 898 87<br>+880 659 785 658 98</p>
	<ul>
	  <li class="address-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<i class="fa fa-address-card"></i>
		  </div>
		  <div class="
			  col-md-10 col-sm-10 col-xs-10
			  single-widget-description
			  noPadding
			">
			<span>Primary: Lorem Ipsum Dolar Sıt</span>
		  </div>
		</div>
	  </li>
	  <li class="address-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<i class="fa fa-phone"></i>
		  </div>
		  <div class="
			  col-md-10 col-sm-10 col-xs-10
			  single-widget-description
			  noPadding
			">
			<span>Primary: Lorem Ipsum Dolar Sıt</span>
		  </div>
		</div>
	  </li>
	  <li class="address-section">
		<div class="row">
		  <div class="col-md-2 col-sm-2 col-xs-2">
			<i class="fa fa-envelope"></i>
		  </div>
		  <div class="
			  col-md-10 col-sm-10 col-xs-10
			  single-widget-description
			  noPadding
			">
			<span>Primary: Lorem Ipsum Dolar Sıt</span>
		  </div>
		</div>
	  </li>
    </ul>'
	)
));
update_option('widget_categories', array(
	1 => array('title' => 'Categories'),
	2 => array('title' => 'Categories')
));

update_option('widget_recent-posts', array(
	1 => array('title' => 'Recent Posts'),
));

update_option('widget_archives', array(
	1 => array('title' => 'Archives'),
	2 => array('title' => 'Archives')
));

update_option('widget_search', array(
	1 => array('title' => 'Search'),
	2 => array('title' => 'Search')
));

update_option('sidebars_widgets',  $activate);
$MediaId = get_option('distantland_media_id');
set_theme_mod('custom_logo', $MediaId[0]);
