<?php
function distantland_footer_above($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'footer_above',
		array(
			'title' => esc_html__('Footer Above Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 4,
		)
	);

	// Footer Above Main Contents
	$wp_customize->add_setting(
		'distantland_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'distantland_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Footer Above Contents', 'distantland'),
			'section' => 'footer_above',
			'priority' => 1,

		)
	);

	// Main Title // 
	$wp_customize->add_setting(
		'above_footer_btm_main_ttl',
		array(
			'default' => esc_html__('CemreBakery Location', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'above_footer_btm_main_ttl',
		array(
			'label'   		=> esc_html__('Main Title', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);

	// Footer Above Main Subtitle // 
	$wp_customize->add_setting(
		'above_footer_btm_main_sub_ttl',
		array(
			'default' => esc_html__('CemreBakery Address', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'distantland_btm_main_sub_ttl',
		array(
			'label'   		=> esc_html__('Main Subtitle', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'text',
			'priority' => 4,
		)
	);

	// Footer Above Main Text // 
	$wp_customize->add_setting(
		'footer_above_btm_main_text',
		array(
			'default' => esc_html__('I must explain to you how all this mistaken idea of denouncing pleure and praising pain was born.', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'footer_above_btm_main_text',
		array(
			'label'   		=> esc_html__('Main Text', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'textarea',
			'priority' => 5,
		)
	);



	// Background Footer Above Main// 
	$wp_customize->add_setting(
		'distantland_bg_footer_above_main',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'distantland_bg_footer_above_main',
		array(
			'type' => 'hidden',
			'label' => __('Background Main', 'distantland'),
			'section' => 'footer_above',
			'priority' => 2,

		)
	);

	// Background Image Footer Above // 
	$wp_customize->add_setting(
		'distantland_bg_img_footer_above_main',
		array(
			'default' 			=> esc_url(get_template_directory_uri() . '/assets/img/address/contactbg.png'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_url',
			'priority' => 2,
		)
	);

	$wp_customize->add_control(new WP_Customize_Image_Control(
		$wp_customize,
		'distantland_bg_img_footer_above_main',
		array(
			'label'          => esc_html__('Background Image', 'distantland'),
			'section'        => 'footer_above',
			'priority' => 2,

		)
	));


	if (class_exists('Customizer_Repeater')) {
		$wp_customize->add_setting('customizer_repeater_example', array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'default' => distantland_get_address_icon_default()
		));
		$wp_customize->add_control(new Customizer_Repeater($wp_customize, 'customizer_repeater_example', array(
			'label'   => esc_html__('Main Social Icons', 'distantland'),
			'section' => 'footer_above',
			'priority' => 8,
			'customizer_repeater_image_control' => false,
			'customizer_repeater_icon_control' => true,
			'customizer_repeater_title_control' => false,
			'customizer_repeater_subtitle_control' => false,
			'customizer_repeater_text_control' => false,
			'customizer_repeater_text2_control' => true,
			'customizer_repeater_link_control' => false,
			'customizer_repeater_link2_control' => false,
			'customizer_repeater_shortcode_control' => false,
			'customizer_repeater_repeater_control' => false,
			'customizer_repeater_color_control' => false,
			'customizer_repeater_color2_control' => false,
		)));
	}

	// Footer Above Sidebar Title // 
	$wp_customize->add_setting(
		'above_footer_btm_sidebar_ttl',
		array(
			'default' => esc_html__('NEW CAKE!!! GET IT FOR $12/PAX (LIMITED)', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'above_footer_btm_sidebar_ttl',
		array(
			'label'   		=> esc_html__('Sidebar Title', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'text',
			'priority' => 12,
		)
	);




	// Footer Above Sidebar Subtitle // 
	$wp_customize->add_setting(
		'above_footer_btm_sidebar_sub_ttl',
		array(
			'default' => esc_html__('Strawberry Pancake', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'above_footer_btm_sidebar_sub_ttl',
		array(
			'label'   		=> esc_html__('Sidebar Subtitle', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'text',
			'priority' => 13,
		)
	);

	// Footer Above Sidebar Text // 
	$wp_customize->add_setting(
		'footer_above_btm_sidebar_text',
		array(
			'default' => esc_html__('Show More', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'footer_above_btm_sidebar_text',
		array(
			'label'   		=> esc_html__('Sidebar Link Text', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'text',
			'priority' => 14,
		)
	);

	// Footer Above Sidebar Link // 
	$wp_customize->add_setting(
		'footer_above_btm_sidebar_link',
		array(
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'footer_above_btm_sidebar_link',
		array(
			'label'   		=> esc_html__('Sidebar Link', 'distantland'),
			'section' 		=> 'footer_above',
			'type'		 =>	'text',
			'priority' => 14,
		)
	);



	// Background Footer Above Banner// 
	$wp_customize->add_setting(
		'distantland_bg_banner_footer_above',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
			'priority' => 15,
		)
	);

	$wp_customize->add_control(
		'distantland_bg_banner_footer_above',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Background Banner', 'distantland'),
			'section' => 'footer_above',
		)
	);

	//Banner Image Footer Above // 
	$wp_customize->add_setting(
		'distantland_bg_banner_img_footer_above',
		array(
			'default' 			=> esc_url(get_template_directory_uri() . '/assets/img/new/shop2.png'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_url',
			'priority' => 15,
		)
	);

	$wp_customize->add_control(new WP_Customize_Image_Control(
		$wp_customize,
		'distantland_bg_banner_img_footer_above',
		array(
			'label'          => esc_html__('Banner Image', 'distantland'),
			'section'        => 'footer_above',
		)
	));
}

add_action('customize_register', 'distantland_footer_above');


// Footer Above selective refresh
function distantland_footer_above_partials($wp_customize)
{

	// footer_above_btm_ttl
	$wp_customize->selective_refresh->add_partial('above_footer_btm_main_ttl', array(
		'selector'            => '.addess-description > span',
		'settings'            => 'above_footer_btm_main_ttl',
		'render_callback'  => 'distantland_above_footer_btm_main_ttl_render_callback',
	));

	// footer_above_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('above_footer_btm_main_sub_ttl', array(
		'selector'            => '.addess-description > h2',
		'settings'            => 'above_footer_btm_main_sub_ttl',
		'render_callback'  => 'distantland_above_footer_btm_main_sub_ttl_render_callback',
	));

	// footer_above_btm_textarea
	$wp_customize->selective_refresh->add_partial('footer_above_btm_main_text', array(
		'selector'            => '.addess-description > p',
		'settings'            => 'footer_above_btm_main_text',
		'render_callback'  => 'distantland_footer_above_btm_main_text_render_callback',
	));



	// above_footer_btm_sidebar_ttl
	$wp_customize->selective_refresh->add_partial('above_footer_btm_sidebar_ttl', array(
		'selector'            => '.adress-area-banner span',
		'settings'            => 'above_footer_btm_sidebar_ttl',
		'render_callback'  => 'distantland_above_footer_btm_sidebar_ttl_render_callback',
	));

	// above_footer_btm_sidebar_sub_ttl
	$wp_customize->selective_refresh->add_partial('above_footer_btm_sidebar_sub_ttl', array(
		'selector'            => '.adress-area-banner h2',
		'settings'            => 'above_footer_btm_sidebar_sub_ttl',
		'render_callback'  => 'distantland_above_footer_btm_sidebar_sub_ttl_render_callback',
	));

	// footer_above_btm_sidebar_text
	$wp_customize->selective_refresh->add_partial('footer_above_btm_sidebar_text', array(
		'selector'            => '.adress-area-banner p',
		'settings'            => 'footer_above_btm_sidebar_text',
		'render_callback'  => 'distantland_footer_above_btm_sidebar_text_render_callback',
	));
}

add_action('customize_register', 'distantland_footer_above_partials');

function distantland_above_footer_btm_main_ttl_render_callback()
{
	return get_theme_mod('above_footer_btm_main_ttl');
}

function distantland_above_footer_btm_main_sub_ttl_render_callback()
{
	return get_theme_mod('above_footer_btm_main_sub_ttl');
}

function distantland_footer_above_btm_main_text_render_callback()
{
	return get_theme_mod('footer_above_btm_main_text');
}

function distantland_above_footer_btm_sidebar_ttl_render_callback()
{
	return get_theme_mod('above_footer_btm_sidebar_ttl');
}

function distantland_above_footer_btm_sidebar_sub_ttl_render_callback()
{
	return get_theme_mod('above_footer_btm_sidebar_sub_ttl');
}

function distantland_footer_above_btm_sidebar_text_render_callback()
{
	return get_theme_mod('footer_above_btm_sidebar_text');
}
