<?php
function distantland_info_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'info_setting',
		array(
			'title' => esc_html__('Info Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 1,
		)
	);

	// info Contents
	$wp_customize->add_setting(
		'info_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'info_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Contents', 'distantland'),
			'section' => 'info_setting',
			'priority'  => 1,

		)
	);


	$wp_customize->add_setting(
		'hide_show_info',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'transport'         => $selective_refresh,
		)
	);

	$wp_customize->add_control(
		'hide_show_info',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'info_setting',
			'type'        => 'checkbox',
			'priority'  => 2,
		)
	);
	/**
	 * Customizer Repeater for add slides
	 */

	$wp_customize->add_setting(
		'info',
		array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_info_default()
		)
	);

	$wp_customize->add_control(
		new Customizer_Repeater(
			$wp_customize,
			'info',
			array(
				'label'   => esc_html__('Info', 'distantland'),
				'section' => 'info_setting',
				'add_field_label'                   => esc_html__('Add New Info', 'distantland'),
				'item_name'                         => esc_html__('Info', 'distantland'),


				'customizer_repeater_image_control' => false,
				'customizer_repeater_icon_control' => false,
				'customizer_repeater_title_control' => true,
				'customizer_repeater_subtitle_control' => true,
				'customizer_repeater_text_control' => true,
				'customizer_repeater_text2_control' => false,
				'customizer_repeater_link_control' => false,
				'customizer_repeater_link2_control' => false,
				'customizer_repeater_shortcode_control' => false,
				'customizer_repeater_repeater_control' => false,
				'customizer_repeater_color_control' => false,
				//'customizer_repeater_color2_control' => true,	
			)
		)
	);
}

add_action('customize_register', 'distantland_info_setting');

// Info selective refresh
function distantland_info_partials($wp_customize)
{

	// hide_show_info
	$wp_customize->selective_refresh->add_partial(
		'hide_show_info',
		array(
			'selector' => '#section1',
			'container_inclusive' => true,
			'render_callback' => 'info_setting',
			'fallback_refresh' => true,
		)
	);
}

add_action('customize_register', 'distantland_info_partials');
