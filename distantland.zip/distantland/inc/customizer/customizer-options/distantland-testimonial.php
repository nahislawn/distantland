<?php
function distantland_testimonial_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'testimonial_setting',
		array(
			'title' => esc_html__('Testimonial Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 1,
		)
	);

	$wp_customize->add_setting(
		'testimonial_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'testimonial_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Testimonial Contents', 'distantland'),
			'section' => 'testimonial_setting',
			'priority' => 1,

		)
	);


	$wp_customize->add_setting(
		'hide_show_testimonial',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'transport'         => $selective_refresh,
		)
	);

	$wp_customize->add_control(
		'hide_show_testimonial',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'testimonial_setting',
			'type'        => 'checkbox',
			'priority'  => 2,
		)
	);


	// Testimonial Title // 
	$wp_customize->add_setting(
		'testimonial_btm_ttl',
		array(
			'default' => esc_html__('What We Say', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'testimonial_btm_ttl',
		array(
			'label'   		=> esc_html__('Title', 'distantland'),
			'section' 		=> 'testimonial_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);


	// Testimonial Subtitle // 
	$wp_customize->add_setting(
		'testimonial_btm_sub_ttl',
		array(
			'default' => esc_html__('Customer Testimonial', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'testimonial_btm_sub_ttl',
		array(
			'label'   		=> esc_html__('Subtitle', 'distantland'),
			'section' 		=> 'testimonial_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);


	// Background // 
	$wp_customize->add_setting(
		'distantland_bg_testimonial',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
			'priority' => 1,
		)
	);

	$wp_customize->add_control(
		'distantland_bg_testimonial',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Background', 'distantland'),
			'section' => 'testimonial_setting',
		)
	);

	// Background Image // 
	$wp_customize->add_setting(
		'distantland_bg_img_testimonial',
		array(
			'default' 			=> esc_url(get_template_directory_uri() . '/assets/img/testimonial/testomonialsbg.png'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_url',
			'priority' => 10,
		)
	);

	$wp_customize->add_control(new WP_Customize_Image_Control(
		$wp_customize,
		'distantland_bg_img_testimonial',
		array(
			'label'          => esc_html__('Background Image', 'distantland'),
			'section'        => 'testimonial_setting',
		)
	));

	/**
	 * Customizer Repeater for add slides
	 */

	$wp_customize->add_setting(
		'testimonial',
		array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_testimonial_default()
		)
	);

	$wp_customize->add_control(
		new Customizer_Repeater(
			$wp_customize,
			'testimonial',
			array(
				'label'   => esc_html__('Testimonial', 'distantland'),
				'section' => 'testimonial_setting',
				'add_field_label'                   => esc_html__('Add New Testimonial', 'distantland'),
				'item_name'                         => esc_html__('Testimonial', 'distantland'),


				'customizer_repeater_image_control' => false,
				'customizer_repeater_icon_control' => false,
				'customizer_repeater_title_control' => true,
				'customizer_repeater_subtitle_control' => true,
				'customizer_repeater_text_control' => true,
				'customizer_repeater_text2_control' => false,
				'customizer_repeater_link_control' => false,
				'customizer_repeater_link2_control' => false,
				'customizer_repeater_shortcode_control' => false,
				'customizer_repeater_repeater_control' => false,
				'customizer_repeater_color_control' => false,
				//'customizer_repeater_color2_control' => true,	
			)
		)
	);
}

add_action('customize_register', 'distantland_testimonial_setting');


// testimonial selective refresh
function distantland_testimonial_partials($wp_customize)
{

	// hide_show_testimonial
	$wp_customize->selective_refresh->add_partial(
		'hide_show_testimonial',
		array(
			'selector' => '#section4',
			'container_inclusive' => true,
			'render_callback' => 'testimonial_setting',
			'fallback_refresh' => true,
		)
	);

	// testimonial_btm_ttl
	$wp_customize->selective_refresh->add_partial('testimonial_btm_ttl', array(
		'selector'            => '#section4 > h3',
		'settings'            => 'testimonial_btm_ttl',
		'render_callback'  => 'distantland_testimonial_btm_ttl_render_callback',
	));

	// testimonial_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('testimonial_btm_sub_ttl', array(
		'selector'            => '#section4 > h2',
		'settings'            => 'testimonial_btm_sub_ttl',
		'render_callback'  => 'distantland_testimonial_btm_sub_ttl_render_callback',
	));
}

add_action('customize_register', 'distantland_testimonial_partials');

function distantland_testimonial_btm_ttl_render_callback()
{
	return get_theme_mod('testimonial_btm_ttl');
}

function distantland_testimonial_btm_sub_ttl_render_callback()
{
	return get_theme_mod('testimonial_btm_sub_ttl');
}
