<?php
function distantland_slider_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'slider_setting',
		array(
			'title' => esc_html__('Slider Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 1,
		)
	);

	// slider Contents
	$wp_customize->add_setting(
		'slider_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'slider_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Contents', 'distantland'),
			'section' => 'slider_setting',
			'priority' => 1,
		)
	);


	/**
	 * Customizer Repeater for add slides
	 */

	$wp_customize->add_setting(
		'slider',
		array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_slider_default()
		)
	);

	$wp_customize->add_control(
		new Customizer_Repeater(
			$wp_customize,
			'slider',
			array(
				'label'   => esc_html__('Slide', 'distantland'),
				'section' => 'slider_setting',
				'add_field_label'                   => esc_html__('Add New Slider', 'distantland'),
				'item_name'                         => esc_html__('Slider', 'distantland'),


				'customizer_repeater_image_control' => true,
				'customizer_repeater_icon_control' => true,
				'customizer_repeater_title_control' => true,
				'customizer_repeater_subtitle_control' => true,
				'customizer_repeater_text_control' => true,
				'customizer_repeater_text2_control' => true,
				'customizer_repeater_link_control' => true,
				'customizer_repeater_link2_control' => false,
				'customizer_repeater_shortcode_control' => false,
				'customizer_repeater_repeater_control' => false,
				//'customizer_repeater_color_control' => true,
				//'customizer_repeater_color2_control' => true,	
			)
		)
	);
}

add_action('customize_register', 'distantland_slider_setting');
