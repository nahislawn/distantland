<?php

/*
 *
 * Social Icon
 */
function distantland_get_social_icon_default()
{
	return apply_filters(
		'distantland_get_social_icon_default',
		json_encode(
			array(
				array(
					'icon_value'	  =>  esc_html__('fa-facebook', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_social_001',
				),
				array(
					'icon_value'	  =>  esc_html__('fa-twitter', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_social_003',
				),
				array(
					'icon_value'	  =>  esc_html__('fa-instagram', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_social_004',
				),
			)
		)
	);
}

/*
 *
 * Adress Icon
 */
function distantland_get_address_icon_default()
{
	return apply_filters(
		'distantland_get_address_icon_default',
		json_encode(
			array(
				array(
					'icon_value'	  =>  esc_html__('fa-address-card', 'distantland'),
					'text'	  =>  esc_html__('Your address goes here, Street City, Roadno 785 New York', 'distantland'),
					'id'              => 'customizer_repeater_address_icons_001',
				),
				array(
					'icon_value'	  =>  esc_html__('fa-phone', 'distantland'),
					'text'	  =>  esc_html__('Primary: Lorem Ipsum', 'distantland'),
					'id'              => 'customizer_repeater_address_icons_003',
				),
				array(
					'icon_value'	  =>  esc_html__('fa-envelope', 'distantland'),
					'text'	  =>  esc_html__('Secondary: Lorem Ipsum', 'distantland'),
					'id'              => 'customizer_repeater_address_icons_004',
				),
			)
		)
	);
}

/*
 *
 * Slider Default
 */
function distantland_get_slider_default()
{
	return apply_filters(
		'distantland_get_slider_default',
		json_encode(
			array(
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/slider/slide.png'),
					'title'           => esc_html__('BAKERY MAKES', 'distantland'),
					'subtitle'         => esc_html__('A Taste Of The Good Life', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
					'text2'	  =>  esc_html__('Learn More', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_slider_001',
				),
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/slider/slide.png'),
					'title'           => esc_html__('BAKERY MAKES', 'distantland'),
					'subtitle'         => esc_html__('A Taste Of The Good Life', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
					'text2'	  =>  esc_html__('Learn More', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_slider_002',
				),
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/slider/slide.png'),
					'title'           => esc_html__('BAKERY MAKES', 'distantland'),
					'subtitle'         => esc_html__('A Taste Of The Good Life', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
					'text2'	  =>  esc_html__('Learn More', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_slider_003',

				),
			)
		)
	);
}

/*
 *
 * Chefs Default
 */
function distantland_get_chefs_default()
{
	return apply_filters(
		'distantland_get_chefs_default',
		json_encode(
			array(
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/item/item2.png'),
					'title'           => esc_html__('Mehmet Akyüz', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_chefs_001',
				),
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/item/item2.png'),
					'title'           => esc_html__('Ceren Deri', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_chefs_002',
				),
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/item/item2.png'),
					'title'           => esc_html__('Merve Akbarı', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_chefs_003',

				),
			)
		)
	);
}

/*
 *
 * Carousel Default
 */
function distantland_get_carousel_default()
{
	return apply_filters(
		'distantland_get_carousel_default',
		json_encode(
			array(
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/new/cake.png'),
					'title'           => esc_html__('Progresso İtalian Style', 'distantland'),
					'text'            => esc_html__('12$', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_carousel_001',
				),
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/new/cake.png'),
					'title'           => esc_html__('Progresso İtalian Style', 'distantland'),
					'text'            => esc_html__('12$', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_carousel_002',
				),
				array(
					'image_url'       => esc_url(get_template_directory_uri() . '/assets/img/new/cake.png'),
					'title'           => esc_html__('Progresso İtalian Style', 'distantland'),
					'text'            => esc_html__('12$', 'distantland'),
					'link'	  =>  esc_html__('#', 'distantland'),
					'id'              => 'customizer_repeater_carousel_003',

				),
			)
		)
	);
}
/*
 *
 * Info Default
 */
function distantland_get_info_default()
{
	return apply_filters(
		'distantland_get_info_default',
		json_encode(
			array(
				array(
					'title'           => esc_html__('Upp to %15 off', 'distantland'),
					'subtitle'           => esc_html__('June Special Offer', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur.', 'distantland'),
					'id'              => 'customizer_repeater_info_001',

				),
				array(
					'title'           => esc_html__('Are You New Here?', 'distantland'),
					'subtitle'           => esc_html__('Learn About Us', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur.', 'distantland'),
					'id'              => 'customizer_repeater_info_002',
				),
				array(
					'title'           => esc_html__('Speacial Bakery', 'distantland'),
					'subtitle'           => esc_html__('Fast Service', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur.', 'distantland'),
					'id'              => 'customizer_repeater_info_003',
				),
			)
		)
	);
}

/*
 *
 * Service Default
 */
function distantland_get_service_default()
{
	return apply_filters(
		'distantland_get_service_default',
		json_encode(
			array(
				array(
					'icon_value'	  =>  esc_html__('fa-university', 'distantland'),
					'title'           => esc_html__('SERVE YOU SINCE 1988', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
					'id'              => 'customizer_repeater_service_001',

				),
				array(
					'icon_value'	  =>  esc_html__('fa-university', 'distantland'),
					'title'           => esc_html__('SERVE YOU SINCE 1988', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
					'id'              => 'customizer_repeater_service_002',
				),
				array(
					'icon_value'	  =>  esc_html__('fa-university', 'distantland'),
					'title'           => esc_html__('SERVE YOU SINCE 1988', 'distantland'),
					'text'            => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
					'id'              => 'customizer_repeater_service_003',
				),
			)
		)
	);
}

/*
 *
 * Testimonial Default
 */

function distantland_get_testimonial_default()
{
	return apply_filters(
		'distantland_get_testimonial_default',
		json_encode(
			array(
				array(
					'title'           => esc_html__('Glenn Maxwell', 'distantland'),
					'subtitle'        => esc_html__('Project Manager', 'distantland'),
					'text'            => esc_html__('This is version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin.', 'distantland'),
					'id'              => 'customizer_repeater_testimonial_001',
				),
				array(
					'title'           => esc_html__('Rizon Pet', 'distantland'),
					'subtitle'        => esc_html__('Ceo', 'distantland'),
					'text'            => esc_html__('This is Photoshop version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin.', 'distantland'),
					'id'              => 'customizer_repeater_testimonial_002',
				),
				array(
					'title'           => esc_html__('Miekel Stark', 'distantland'),
					'subtitle'        => esc_html__('Cto', 'distantland'),
					'text'            => esc_html__('This is version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin.', 'distantland'),
					'id'              => 'customizer_repeater_testimonial_003',
				),
			)
		)
	);
}
