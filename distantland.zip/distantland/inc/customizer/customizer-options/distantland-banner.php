<?php
function distantland_banner_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'banner_setting',
		array(
			'title' => esc_html__('Banner Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 1,
		)
	);

	// Banner Contents
	$wp_customize->add_setting(
		'distantland_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'distantland_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Banner Contents', 'distantland'),
			'section' => 'banner_setting',
			'priority' => 1,

		)
	);


	$wp_customize->add_setting(
		'hide_show_banner',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'transport'         => $selective_refresh,
		)
	);

	$wp_customize->add_control(
		'hide_show_banner',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'banner_setting',
			'type'        => 'checkbox',
			'priority'  => 2,
		)
	);


	// Banner Title // 
	$wp_customize->add_setting(
		'banner_btm_ttl',
		array(
			'default' => esc_html__('NEW CAKE!!! GET IT FOR $12/PAX (LIMITED)', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'banner_btm_ttl',
		array(
			'label'   		=> esc_html__('Title', 'distantland'),
			'section' 		=> 'banner_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);




	// Banner Subtitle // 
	$wp_customize->add_setting(
		'banner_btm_sub_ttl',
		array(
			'default' => esc_html__('Strawberry Pancake', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'banner_btm_sub_ttl',
		array(
			'label'   		=> esc_html__('Subtitle', 'distantland'),
			'section' 		=> 'banner_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);

	// Banner Text // 
	$wp_customize->add_setting(
		'banner_btm_text',
		array(
			'default' => esc_html__('Show More', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'banner_btm_text',
		array(
			'label'   		=> esc_html__('Text', 'distantland'),
			'section' 		=> 'banner_setting',
			'type'		 =>	'textarea',
			'priority' => 3,
		)
	);


	// Banner Link // 
	$wp_customize->add_setting(
		'banner_btm_link',
		array(
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'banner_btm_link',
		array(
			'label'   		=> esc_html__('Link', 'distantland'),
			'section' 		=> 'banner_setting',
			'type'		 =>	'text',
			'priority' => 4,
		)
	);


	// Background // 
	$wp_customize->add_setting(
		'distantland_bg_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
			'priority' => 1,
		)
	);

	$wp_customize->add_control(
		'distantland_bg_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Background', 'distantland'),
			'section' => 'banner_setting',
		)
	);

	// Background Image // 
	$wp_customize->add_setting(
		'distantland_bg_img',
		array(
			'default' 			=> esc_url(get_template_directory_uri() . '/assets/img/new/shop.png'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_url',
			'priority' => 10,
		)
	);

	$wp_customize->add_control(new WP_Customize_Image_Control(
		$wp_customize,
		'distantland_bg_img',
		array(
			'label'          => esc_html__('Background Image', 'distantland'),
			'section'        => 'banner_setting',
		)
	));
}

add_action('customize_register', 'distantland_banner_setting');


// Banner selective refresh
function distantland_banner_partials($wp_customize)
{

	// hide_show_banner
	$wp_customize->selective_refresh->add_partial(
		'hide_show_banner',
		array(
			'selector' => '.banner',
			'container_inclusive' => true,
			'render_callback' => 'banner_setting',
			'fallback_refresh' => true,
		)
	);

	// banner_btm_ttl
	$wp_customize->selective_refresh->add_partial('banner_btm_ttl', array(
		'selector'            => '.banner > .content > span',
		'settings'            => 'banner_btm_ttl',
		'render_callback'  => 'distantland_banner_btm_ttl_render_callback',
	));

	// banner_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('banner_btm_sub_ttl', array(
		'selector'            => '.banner > .content > h2',
		'settings'            => 'banner_btm_sub_ttl',
		'render_callback'  => 'distantland_banner_btm_sub_ttl_render_callback',
	));

	// banner_btm_textarea
	$wp_customize->selective_refresh->add_partial('banner_btm_text', array(
		'selector'            => '.banner > .content > h3',
		'settings'            => 'banner_btm_text',
		'render_callback'  => 'distantland_banner_btm_text_render_callback',
	));
}

add_action('customize_register', 'distantland_banner_partials');

function distantland_banner_btm_ttl_render_callback()
{
	return get_theme_mod('banner_btm_ttl');
}

function distantland_banner_btm_sub_ttl_render_callback()
{
	return get_theme_mod('banner_btm_sub_ttl');
}

function distantland_banner_btm_text_render_callback()
{
	return get_theme_mod('banner_btm_text');
}
