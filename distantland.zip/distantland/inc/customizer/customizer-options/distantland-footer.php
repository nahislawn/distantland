<?php
function distantland_footer($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	// Footer Panel // 
	$wp_customize->add_panel(
		'footer_section',
		array(
			'priority'      => 34,
			'capability'    => 'edit_theme_options',
			'title'			=> esc_html__('Footer', 'distantland'),
		)
	);

	// Footer Top // 
	$wp_customize->add_section(
		'footer_top',
		array(
			'title' 		=> esc_html__('Footer Top', 'distantland'),
			'panel'  		=> 'footer_section',
			'priority'      => 2,
		)
	);



	// Footer Bottom // 
	$wp_customize->add_section(
		'footer_bottom',
		array(
			'title' 		=> esc_html__('Footer Bottom', 'distantland'),
			'panel'  		=> 'footer_section',
			'priority'      => 3,
		)
	);



	// Footer Info 
	$wp_customize->add_setting(
		'footer_btm_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'footer_btm_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Info', 'distantland'),
			'section' => 'footer_top',
			'priority'  => 1,
		)
	);


	// Footer Title // 
	$wp_customize->add_setting(
		'footer_btm_ttl',
		array(
			'default' => esc_html__('Fresh Bakery Store', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'footer_btm_ttl',
		array(
			'label'   		=> esc_html__('Title', 'distantland'),
			'section' 		=> 'footer_top',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);

	// Footer Text // 
	$wp_customize->add_setting(
		'footer_btm_text',
		array(
			'default' => esc_html__('I must explain to you how all this mistaken idea of denouncing pleure and praising pain was born.', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'footer_btm_text',
		array(
			'label'   		=> esc_html__('Text', 'distantland'),
			'section' 		=> 'footer_top',
			'type'		 =>	'textarea',
			'priority' => 4,
		)
	);


	// Footer Logo // 
	$wp_customize->add_setting(
		'footer_bg_logo_img',
		array(
			'default' 			=> esc_url(get_template_directory_uri() . '/assets/img/logo/cemrebakerytextlogo.png'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_url',
			'priority' => 10,
		)
	);

	$wp_customize->add_control(new WP_Customize_Image_Control(
		$wp_customize,
		'footer_bg_logo_img',
		array(
			'label'          => esc_html__('Footer Logo', 'distantland'),
			'section'        => 'footer_top',
		)
	));


	// Footer Copyright 


	$wp_customize->add_setting(
		'footer_btm_copy_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
			'priority'  => 3,
		)
	);

	$wp_customize->add_control(
		'footer_btm_copy_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Copyright', 'distantland'),
			'section' => 'footer_bottom',
		)
	);

	$distantland_foo_copy = esc_html__('Copyright &copy; [current_year] [site_title] | Powered by [theme_author]', 'distantland');
	$wp_customize->add_setting(
		'footer_copyright',
		array(
			'default' => $distantland_foo_copy,
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'wp_kses_post',
			'priority'      => 4,
		)
	);

	$wp_customize->add_control(
		'footer_copyright',
		array(
			'label'   		=> esc_html__('Copyright', 'distantland'),
			'section'		=> 'footer_bottom',
			'type' 			=> 'textarea',
			'transport'         => $selective_refresh,
		)
	);




	if (class_exists('Customizer_Repeater')) {
		$wp_customize->add_setting('customizer_repeater_social_icons', array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_social_icon_default()
		));
		$wp_customize->add_control(new Customizer_Repeater($wp_customize, 'customizer_repeater_social_icons', array(
			'label'   => esc_html__('Social Icons', 'distantland'),
			'section' => 'footer_top',
			'priority' => 5,
			'customizer_repeater_image_control' => false,
			'customizer_repeater_icon_control' => true,
			'customizer_repeater_title_control' => false,
			'customizer_repeater_subtitle_control' => false,
			'customizer_repeater_text_control' => false,
			'customizer_repeater_text2_control' => false,
			'customizer_repeater_link_control' => false,
			'customizer_repeater_link2_control' => true,
			'customizer_repeater_shortcode_control' => false,
			'customizer_repeater_repeater_control' => false,
			'customizer_repeater_color_control' => false,
			'customizer_repeater_color2_control' => false,
		)));
	}
}
add_action('customize_register', 'distantland_footer');
// Footer selective refresh
function distantland_footer_partials($wp_customize)
{

	// footer_btm_ttl
	$wp_customize->selective_refresh->add_partial('footer_btm_ttl', array(
		'selector'            => '.footer-title',
		'settings'            => 'footer_btm_ttl',
		'render_callback'  => 'distantland_footer_btm_ttl_render_callback',
	));

	// footer_btm_text
	$wp_customize->selective_refresh->add_partial('footer_btm_text', array(
		'selector'            => '.footer-text',
		'settings'            => 'footer_btm_text',
		'render_callback'  => 'distantland_footer_btm_text_render_callback',
	));

	// footer_copyright
	$wp_customize->selective_refresh->add_partial('footer_copyright', array(
		'selector'            => '.copyright-text',
		'settings'            => 'footer_copyright',
		'render_callback'  => 'distantland_footer_copyright_render_callback',
	));
}

add_action('customize_register', 'distantland_footer_partials');

// footer_btm_ttl
function distantland_footer_btm_ttl_render_callback()
{
	return get_theme_mod('footer_btm_ttl');
}
// footer_btm_text
function distantland_footer_btm_text_render_callback()
{
	return get_theme_mod('footer_btm_text');
}

// copyright_content
function distantland_footer_copyright_render_callback()
{
	return get_theme_mod('footer_copyright');
}
