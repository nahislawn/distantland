<?php
function distantland_blog_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	/*=========================================
	Frontpage Panel
	=========================================*/
	$wp_customize->add_panel(
		'distantland_frontpage_sections',
		array(
			'priority' => 32,
			'title' => esc_html__('Frontpage Sections', 'distantland'),
		)
	);

	/*=========================================
	Distantland Blog Section
	=========================================*/
	$wp_customize->add_section(
		'distantland_blog_setting',
		array(
			'title' => esc_html__('Blog Section', 'distantland'),
			'priority' => 2,
			'panel' => 'distantland_frontpage_sections',
		)
	);

	// Distantland Blog Settings Section // 

	$wp_customize->add_setting(
		'distantland_blog_setting_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
			'priority' => 5,
		)
	);

	$wp_customize->add_control(
		'distantland_blog_setting_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Settings', 'distantland'),
			'section' => 'distantland_blog_setting',
		)
	);
	// hide/show
	$wp_customize->add_setting(
		'hs_distantland_blog',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'priority' => 6,
		)
	);

	$wp_customize->add_control(
		'hs_distantland_blog',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'distantland_blog_setting',
			'type'        => 'checkbox',
		)
	);

	// distantland_blog Header Section // 
	$wp_customize->add_setting(
		'distantland_blog_headings',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
			'priority' => 3,
		)
	);

	$wp_customize->add_control(
		'distantland_blog_headings',
		array(
			'type' => 'hidden',
			'label' => __('Header', 'distantland'),
			'section' => 'distantland_blog_setting',
		)
	);

	// Distantland Blog Title // 
	$wp_customize->add_setting(
		'distantland_blog_title',
		array(
			'default' => esc_html__('Distantland Blog', 'distantland'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_html',
			'transport'         => $selective_refresh,
			'priority' => 4,
		)
	);

	$wp_customize->add_control(
		'distantland_blog_title',
		array(
			'label'   => __('Title', 'distantland'),
			'section' => 'distantland_blog_setting',
			'type'           => 'text',
		)
	);

	// distantland_blog Subtitle // 
	$wp_customize->add_setting(
		'distantland_blog_subtitle',
		array(
			'default' => esc_html__('Our Latest News', 'distantland'),
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_html',
			'transport'         => $selective_refresh,
			'priority' => 5,
		)
	);

	$wp_customize->add_control(
		'distantland_blog_subtitle',
		array(
			'label'   => esc_html__('Subtitle', 'distantland'),
			'section' => 'distantland_blog_setting',
			'type'           => 'text',
		)
	);
}

add_action('customize_register', 'distantland_blog_setting');

// distantland_blog selective refresh
function distantland_blog_partials($wp_customize)
{

	// hide_show_distantland_blog
	$wp_customize->selective_refresh->add_partial(
		'hs_distantland_blog',
		array(
			'selector' => '#section5',
			'container_inclusive' => true,
			'render_callback' => 'distantland_blog_setting',
			'fallback_refresh' => true,
		)
	);

	// distantland_blog_btm_ttl
	$wp_customize->selective_refresh->add_partial('distantland_blog_title', array(
		'selector'            => '#section5 h3',
		'settings'            => 'distantland_blog_title',
		'render_callback'  => 'distantland_blog_title_render_callback',
	));

	// distantland_blog_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('distantland_blog_subtitle', array(
		'selector'            => '#section5 h2',
		'settings'            => 'distantland_blog_subtitle',
		'render_callback'  => 'distantland_blog_subtitle_render_callback',
	));
}

add_action('customize_register', 'distantland_blog_partials');

function distantland_blog_title_render_callback()
{
	return get_theme_mod('distantland_blog_title');
}

function distantland_blog_subtitle_render_callback()
{
	return get_theme_mod('distantland_blog_subtitle');
}
