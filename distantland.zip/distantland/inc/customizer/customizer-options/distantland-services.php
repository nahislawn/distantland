<?php
function distantland_services_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'services_setting',
		array(
			'title' => esc_html__('Services Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 1,
		)
	);

	$wp_customize->add_setting(
		'services_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'services_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Services Contents', 'distantland'),
			'section' => 'services_setting',
			'priority' => 1,

		)
	);


	$wp_customize->add_setting(
		'hide_show_services',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'transport'         => $selective_refresh,
		)
	);

	$wp_customize->add_control(
		'hide_show_services',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'services_setting',
			'type'        => 'checkbox',
			'priority'  => 2,
		)
	);


	// Service Title // 
	$wp_customize->add_setting(
		'services_btm_ttl',
		array(
			'default' => esc_html__('SERVE YOU SINCE 1988', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'services_btm_ttl',
		array(
			'label'   		=> esc_html__('Title', 'distantland'),
			'section' 		=> 'services_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);


	// Service Subtitle // 
	$wp_customize->add_setting(
		'services_btm_sub_ttl',
		array(
			'default' => esc_html__('Welcome To Cemre Bakery', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'services_btm_sub_ttl',
		array(
			'label'   		=> esc_html__('Subtitle', 'distantland'),
			'section' 		=> 'services_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);

	// Service Text // 
	$wp_customize->add_setting(
		'services_btm_textarea',
		array(
			'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum sagittis leo vitae lacinia congue.', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'services_btm_textarea',
		array(
			'label'   		=> esc_html__('Text', 'distantland'),
			'section' 		=> 'services_setting',
			'type'		 =>	'textarea',
			'priority' => 4,
		)
	);



	/**
	 * Customizer Repeater for add slides
	 */

	$wp_customize->add_setting(
		'services',
		array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_service_default()
		)
	);

	$wp_customize->add_control(
		new Customizer_Repeater(
			$wp_customize,
			'services',
			array(
				'label'   => esc_html__('Services', 'distantland'),
				'section' => 'services_setting',
				'add_field_label'                   => esc_html__('Add New Services', 'distantland'),
				'item_name'                         => esc_html__('Services', 'distantland'),


				'customizer_repeater_image_control' => false,
				'customizer_repeater_icon_control' => true,
				'customizer_repeater_title_control' => true,
				//'customizer_repeater_subtitle_control' => true,
				'customizer_repeater_text_control' => true,
				'customizer_repeater_text2_control' => false,
				'customizer_repeater_link_control' => false,
				'customizer_repeater_link2_control' => false,
				'customizer_repeater_shortcode_control' => false,
				'customizer_repeater_repeater_control' => false,
				'customizer_repeater_color_control' => true,
				//'customizer_repeater_color2_control' => true,	
			)
		)
	);
}

add_action('customize_register', 'distantland_services_setting');


// Services selective refresh
function distantland_services_partials($wp_customize)
{

	// hide_show_services
	$wp_customize->selective_refresh->add_partial(
		'hide_show_services',
		array(
			'selector' => '#section2',
			'container_inclusive' => true,
			'render_callback' => 'services_setting',
			'fallback_refresh' => true,
		)
	);

	// services_btm_ttl
	$wp_customize->selective_refresh->add_partial('services_btm_ttl', array(
		'selector'            => '.maintext > span',
		'settings'            => 'services_btm_ttl',
		'render_callback'  => 'distantland_services_btm_ttl_render_callback',
	));

	// services_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('services_btm_sub_ttl', array(
		'selector'            => '.maintext > h2',
		'settings'            => 'services_btm_sub_ttl',
		'render_callback'  => 'distantland_services_btm_sub_ttl_render_callback',
	));

	// services_btm_textarea
	$wp_customize->selective_refresh->add_partial('service_btm_textarea', array(
		'selector'            => '.maintext > p',
		'settings'            => 'services_btm_textarea',
		'render_callback'  => 'distantland_services_btm_textarea_render_callback',
	));
}

add_action('customize_register', 'distantland_services_partials');

function distantland_services_btm_ttl_render_callback()
{
	return get_theme_mod('services_btm_ttl');
}

function distantland_services_btm_sub_ttl_render_callback()
{
	return get_theme_mod('services_btm_sub_ttl');
}

function distantland_services_btm_textarea_render_callback()
{
	return get_theme_mod('services_btm_textarea');
}
