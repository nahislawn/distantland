<?php
function distantland_chefs_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'chefs_setting',
		array(
			'title' => esc_html__('Chefs Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 3,
		)
	);

	$wp_customize->add_setting(
		'chefs_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'chefs_content_head',
		array(
			'type' => 'hidden',
			'label' => esc_html__('Chefs Contents', 'distantland'),
			'section' => 'chefs_setting',
			'priority' => 1,

		)
	);


	$wp_customize->add_setting(
		'hide_show_chefs',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'transport'         => $selective_refresh,
		)
	);

	$wp_customize->add_control(
		'hide_show_chefs',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'chefs_setting',
			'type'        => 'checkbox',
			'priority'  => 2,
		)
	);


	// Chefs Title // 
	$wp_customize->add_setting(
		'chefs_btm_ttl',
		array(
			'default' => esc_html__('Our Chefs', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'chefs_btm_ttl',
		array(
			'label'   		=> esc_html__('Title', 'distantland'),
			'section' 		=> 'chefs_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);


	// Chefs Subtitle // 
	$wp_customize->add_setting(
		'chefs_btm_sub_ttl',
		array(
			'default' => esc_html__('Our latest chefs', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'chefs_btm_sub_ttl',
		array(
			'label'   		=> esc_html__('Subtitle', 'distantland'),
			'section' 		=> 'chefs_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);

	/**
	 * Customizer Repeater for add slides
	 */

	$wp_customize->add_setting(
		'chefs',
		array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_chefs_default()
		)
	);

	$wp_customize->add_control(
		new Customizer_Repeater(
			$wp_customize,
			'chefs',
			array(
				'label'   => esc_html__('Chefs', 'distantland'),
				'section' => 'chefs_setting',
				'add_field_label'                   => esc_html__('Add New Chef', 'distantland'),
				'item_name'                         => esc_html__('Chef', 'distantland'),


				'customizer_repeater_image_control' => true,
				'customizer_repeater_icon_control' => true,
				'customizer_repeater_title_control' => true,
				'customizer_repeater_subtitle_control' => false,
				'customizer_repeater_text_control' => false,
				'customizer_repeater_text2_control' => false,
				'customizer_repeater_link_control' => true,
				'customizer_repeater_link2_control' => false,
				'customizer_repeater_shortcode_control' => false,
				'customizer_repeater_repeater_control' => false,
				'customizer_repeater_color_control' => false,
				//'customizer_repeater_color2_control' => true,	
			)
		)
	);
}

add_action('customize_register', 'distantland_chefs_setting');

// chefs selective refresh
function distantland_chefs_partials($wp_customize)
{

	// hide_show_chefs
	$wp_customize->selective_refresh->add_partial(
		'hide_show_chefs',
		array(
			'selector' => '#section6',
			'container_inclusive' => true,
			'render_callback' => 'chefs_setting',
			'fallback_refresh' => true,
		)
	);

	// chefs_btm_ttl
	$wp_customize->selective_refresh->add_partial('chefs_btm_ttl', array(
		'selector'            => '#section6 h3',
		'settings'            => 'chefs_btm_ttl',
		'render_callback'  => 'distantland_chefs_btm_ttl_render_callback',
	));

	// chefs_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('chefs_btm_sub_ttl', array(
		'selector'            => '#section6 h2',
		'settings'            => 'chefs_btm_sub_ttl',
		'render_callback'  => 'distantland_chefs_btm_sub_ttl_render_callback',
	));
}

add_action('customize_register', 'distantland_chefs_partials');

function distantland_chefs_btm_ttl_render_callback()
{
	return get_theme_mod('chefs_btm_ttl');
}

function distantland_chefs_btm_sub_ttl_render_callback()
{
	return get_theme_mod('chefs_btm_sub_ttl');
}
