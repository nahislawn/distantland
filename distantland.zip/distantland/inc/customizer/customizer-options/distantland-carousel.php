<?php
function distantland_carousel_setting($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	$wp_customize->add_section(
		'carousel_setting',
		array(
			'title' => esc_html__('Carousel Section', 'distantland'),
			'panel' => 'distantland_frontpage_sections',
			'priority' => 1,
		)
	);

	//Contents
	$wp_customize->add_setting(
		'carousel_content_head',
		array(
			'capability'     	=> 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_text',
		)
	);

	$wp_customize->add_control(
		'carousel_content_head',
		array(
			'type' => 'hidden',
			'label' => __('Carousel', 'distantland'),
			'section' => 'carousel_setting',
			'priority' => 1,

		)
	);


	$wp_customize->add_setting(
		'hide_show_carousel',
		array(
			'default' => '1',
			'capability'     => 'edit_theme_options',
			'sanitize_callback' => 'distantland_sanitize_checkbox',
			'transport'         => $selective_refresh,
		)
	);

	$wp_customize->add_control(
		'hide_show_carousel',
		array(
			'label'	      => esc_html__('Hide/Show', 'distantland'),
			'section'     => 'carousel_setting',
			'type'        => 'checkbox',
			'priority'  => 2,
		)
	);


	// Carousel Title // 
	$wp_customize->add_setting(
		'carousel_btm_ttl',
		array(
			'default' => esc_html__('PREMIUM QUALITY', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'carousel_btm_ttl',
		array(
			'label'   		=> esc_html__('Title', 'distantland'),
			'section' 		=> 'carousel_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);


	// Carousel Subtitle // 
	$wp_customize->add_setting(
		'carousel_btm_sub_ttl',
		array(
			'default' => esc_html__('Cemre Bakery Fresh Cakes', 'distantland'),
			'sanitize_callback' => 'distantland_sanitize_text',
			'transport'         => $selective_refresh,
			'capability' => 'edit_theme_options',
		)
	);

	$wp_customize->add_control(
		'carousel_btm_sub_ttl',
		array(
			'label'   		=> esc_html__('Subtitle', 'distantland'),
			'section' 		=> 'carousel_setting',
			'type'		 =>	'text',
			'priority' => 3,
		)
	);

	/**
	 * Customizer Repeater for add slides
	 */

	$wp_customize->add_setting(
		'carousel',
		array(
			'sanitize_callback' => 'customizer_repeater_sanitize',
			'priority' => 5,
			'default' => distantland_get_slider_default()
		)
	);

	$wp_customize->add_control(
		new Customizer_Repeater(
			$wp_customize,
			'carousel',
			array(
				'label'   => esc_html__('Carousel Item', 'distantland'),
				'section' => 'carousel_setting',
				'add_field_label'                   => esc_html__('Add New Carousel Item', 'distantland'),
				'item_name'                         => esc_html__('Carousel Item', 'distantland'),


				'customizer_repeater_image_control' => true,
				'customizer_repeater_icon_control' => true,
				'customizer_repeater_title_control' => true,
				'customizer_repeater_subtitle_control' => false,
				'customizer_repeater_text_control' => true,
				'customizer_repeater_text2_control' => false,
				'customizer_repeater_link_control' => true,
				'customizer_repeater_link2_control' => false,
				'customizer_repeater_shortcode_control' => false,
				'customizer_repeater_repeater_control' => false,
				'customizer_repeater_color_control' => false,
				'customizer_repeater_color2_control' => false,
			)
		)
	);
}

add_action('customize_register', 'distantland_carousel_setting');

// carousel selective refresh
function distantland_carousel_partials($wp_customize)
{

	// hide_show_carousel
	$wp_customize->selective_refresh->add_partial(
		'hide_show_carousel',
		array(
			'selector' => '#section3',
			'container_inclusive' => true,
			'render_callback' => 'carousel_setting',
			'fallback_refresh' => true,
		)
	);

	// carousel_btm_ttl
	$wp_customize->selective_refresh->add_partial('carousel_btm_ttl', array(
		'selector'            => '#section3 .section-title > h3',
		'settings'            => 'carousel_btm_ttl',
		'render_callback'  => 'distantland_carousel_btm_ttl_render_callback',
	));

	// carousel_btm_sub_ttl
	$wp_customize->selective_refresh->add_partial('carousel_btm_sub_ttl', array(
		'selector'            => '#section3 .section-title > h2',
		'settings'            => 'carousel_btm_sub_ttl',
		'render_callback'  => 'distantland_carousel_btm_sub_ttl_render_callback',
	));
}

add_action('customize_register', 'distantland_carousel_partials');

function distantland_carousel_btm_ttl_render_callback()
{
	return get_theme_mod('carousel_btm_ttl');
}

function distantland_carousel_btm_sub_ttl_render_callback()
{
	return get_theme_mod('carousel_btm_sub_ttl');
}
