<?php
function distantland_header_settings($wp_customize)
{
	$selective_refresh = isset($wp_customize->selective_refresh) ? 'postMessage' : 'refresh';
	/*=========================================
	Header Settings Panel
	=========================================*/
	$wp_customize->add_panel(
		'header_section',
		array(
			'priority'      => 2,
			'capability'    => 'edit_theme_options',
			'title'			=> __('Header', 'distantland'),
		)
	);

	/*=========================================
	Distantland Site Identity
	=========================================*/
	$wp_customize->add_section(
		'title_tagline',
		array(
			'priority'      => 1,
			'title' 		=> esc_html__('Site Identity', 'distantland'),
			'panel'  		=> 'header_section',
		)
	);
}
add_action('customize_register', 'distantland_header_settings');
