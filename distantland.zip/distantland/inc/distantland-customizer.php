<?php

/**
 * Distantland Theme Customizer.
 *
 * @package Distantland
 */

if (!class_exists('Distantland_Customizer')) {

	/**
	 * Customizer Loader
	 *
	 * @since 1.0
	 */
	class Distantland_Customizer
	{

		/**
		 * Instance
		 *
		 * @access private
		 * @var object
		 */
		private static $instance;

		/**
		 * Initiator
		 */
		public static function get_instance()
		{
			if (!isset(self::$instance)) {
				self::$instance = new self;
			}
			return self::$instance;
		}

		/**
		 * Constructor
		 */
		public function __construct()
		{
			/**
			 * Customizer
			 */
			add_action('customize_preview_init',                  array($this, 'distantland_customize_preview_js'));
			add_action('customize_register',                      array($this, 'distantland_customizer_register'));
			add_action('after_setup_theme',                       array($this, 'distantland_customizer_settings'));
		}

		/**
		 * Add postMessage support for site title and description for the Theme Customizer.
		 *
		 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
		 */
		function distantland_customizer_register($wp_customize)
		{

			$wp_customize->get_setting('blogname')->transport         = 'postMessage';
			$wp_customize->get_setting('blogdescription')->transport  = 'postMessage';
			$wp_customize->get_setting('header_textcolor')->transport = 'postMessage';
			$wp_customize->get_setting('background_color')->transport = 'postMessage';
			$wp_customize->get_setting('custom_logo')->transport = 'refresh';

			/**
			 * Helper files
			 */
			//require DISTANTLAND_PARENT_INC_DIR . '/customizer/controls/font-control.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/sanitization.php';
		}

		/**
		 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
		 */
		function distantland_customize_preview_js()
		{
			wp_enqueue_script('distantland-customizer', DISTANTLAND_PARENT_INC_URI . '/customizer/assets/js/customizer-preview.js', array('customize-preview'), '20151215', true);
		}

		// Include customizer customizer settings.

		function distantland_customizer_settings()
		{
			/**
			 * Load Custom control in Customizer
			 */

			-require DISTANTLAND_PARENT_INC_DIR . '/custom-controls/customizer-repeater/functions.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-header.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-blog.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-footer.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/extras.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-slider.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-info.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-services.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-banner.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-carousel.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-testimonial.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-chefs.php';
			require DISTANTLAND_PARENT_INC_DIR . '/customizer/customizer-options/distantland-above-footer.php';

			if (!function_exists('distantland_frontpage_sections')) :
				function distantland_frontpage_sections()
				{
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-slider.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-info.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-services.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-banner.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-carousel.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-testimonial.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-blog.php';
					require DISTANTLAND_PARENT_INC_DIR . '/customizer/theme-defaults/sections/section-chefs.php';
				}
				add_action('distantland_sections', 'distantland_frontpage_sections');
			endif;
		}
	}
} // End if().

/**
 *  Kicking this off by calling 'get_instance()' method
 */
Distantland_Customizer::get_instance();
